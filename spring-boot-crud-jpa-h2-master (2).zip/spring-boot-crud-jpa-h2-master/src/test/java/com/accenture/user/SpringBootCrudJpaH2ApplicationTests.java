package com.accenture.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudJpaH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
