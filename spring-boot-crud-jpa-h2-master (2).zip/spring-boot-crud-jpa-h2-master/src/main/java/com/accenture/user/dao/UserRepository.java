package com.accenture.user.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accenture.user.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {

}
