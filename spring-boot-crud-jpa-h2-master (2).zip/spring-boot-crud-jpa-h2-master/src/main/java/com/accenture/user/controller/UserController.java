package com.accenture.user.controller;

import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.accenture.user.entity.User;
import com.accenture.user.service.UserService;

@RestController
@RequestMapping("/api/user")
@Api(value = "User API", tags = { "User Controller" })
public class UserController {
	@Autowired
	private UserService userService;

	@ApiOperation(value = "save a user", notes = "This method is for saving user  to the db")
	@PostMapping("/addUser")
	public User addUser(@RequestBody User user) {
		return userService.createUser(user);
	}

	@ApiOperation(value = "add group of users", notes = "This method is for saving users  to the db")
	@PostMapping("/addUsers")
	public List<User> addUsers(@RequestBody List<User> users) {
		return userService.createUsers(users);
	}

	@ApiOperation(value = "find by id", notes = "This method is for finding user  from the db")
	@GetMapping("/user/{id}")
	public User getUserById(@PathVariable int id) {
		return userService.getUserById(id);
	}

	@ApiOperation(value = "get all users", notes = "This method is for retrieving all users")
	@GetMapping("/users")
	public List<User> getAllUsers() {
		return userService.getUsers();
	}

	@ApiOperation(value = "update a user", notes = "This method is for update user  to the db")
	@PutMapping("/updateuser")
	public User updateUser(@RequestBody User user) {
		return userService.updateUser(user);
	}

	@ApiOperation(value = "delete the  user by id", notes = "This method is for saving user  to the db")
	@DeleteMapping("/user/{id}")
	public String deleteUser(@PathVariable int id) {
		return userService.deleteUserById(id);
	}
}
